// static/js/main.js - JavaScript principal

document.addEventListener('DOMContentLoaded', function() {
    // Inicialización de tooltips de Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Gestión de alertas
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000); // Auto-cerrar después de 5 segundos
    });
    
    // Función para mostrar el menú de navegación responsivo
    const toggleMenu = document.getElementById('toggleMenu');
    if (toggleMenu) {
        toggleMenu.addEventListener('click', function() {
            const mainMenu = document.querySelector('.main-menu-items');
            mainMenu.classList.toggle('show');
        });
    }
    
    // Función para actualizar el contador de notificaciones
    function updateNotificationCount() {
        const notificationBadge = document.querySelector('.notification-badge');
        if (notificationBadge) {
            // Simulación de datos - en un entorno real, estos datos vendrían del servidor
            fetch('/api/notifications/count')
                .then(response => response.json())
                .then(data => {
                    notificationBadge.textContent = data.count;
                    if (data.count > 0) {
                        notificationBadge.classList.remove('d-none');
                    } else {
                        notificationBadge.classList.add('d-none');
                    }
                })
                .catch(error => {
                    console.error('Error al obtener las notificaciones:', error);
                });
        }
    }
    
    // Simulación de la función fetch para el ejemplo
    window.fetch = function(url) {
        if (url === '/api/notifications/count') {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve({
                        json: () => Promise.resolve({ count: 3 })
                    });
                }, 500);
            });
        }
        return originalFetch.apply(this, arguments);
    };
    
    // Llamar a la función al cargar la página
    updateNotificationCount();
    
    // Actualizar cada 5 minutos
    setInterval(updateNotificationCount, 300000);
    
    // Inicialización del mapa en la página del dashboard
    const mapElement = document.getElementById('map');
    if (mapElement) {
        // Aquí se podría inicializar un mapa real con una biblioteca como Leaflet o Google Maps
        console.log('Inicializando mapa...');
        
        // Ejemplo de inicialización de Leaflet (requeriría incluir la biblioteca)
        /*
        const map = L.map('map').setView([20.59, -103.42], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        
        // Agregar marcadores para cada campo
        const fields = [
            { lat: 20.58, lng: -103.41, name: 'Campo A' },
            { lat: 20.60, lng: -103.43, name: 'Campo B' },
            { lat: 20.59, lng: -103.40, name: 'Invernadero 3' }
        ];
        
        fields.forEach(field => {
            L.marker([field.lat, field.lng])
                .addTo(map)
                .bindPopup(field.name);
        });
        */
    }
    
    // Inicialización de gráficos en la página de análisis
    const chartElements = document.querySelectorAll('.chart-container');
    if (chartElements.length > 0) {
        // Aquí se podrían inicializar gráficos con una biblioteca como Chart.js
        console.log('Inicializando gráficos...');
        
        // Ejemplo de inicialización de Chart.js (requeriría incluir la biblioteca)
        /*
        chartElements.forEach((element, index) => {
            const ctx = element.getContext('2d');
            const chartType = element.dataset.chartType;
            const chartData = JSON.parse(element.dataset.chartData);
            
            new Chart(ctx, {
                type: chartType,
                data: chartData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        });
        */
    }
});

// Funciones para gestionar los cultivos
function confirmDeleteCrop(cropId, cropName) {
    if (confirm(`¿Está seguro que desea eliminar el cultivo "${cropName}"?`)) {
        window.location.href = `/crop/delete/${cropId}`;
    }
}

// Funciones para gestionar las recomendaciones
function markRecommendationAsApplied(recommendationId) {
    // En un entorno real, esto sería una llamada AJAX al servidor
    console.log(`Marcar recomendación ${recommendationId} como aplicada`);
    alert('Recomendación marcada como aplicada');
    
    // Actualizar la interfaz de usuario
    const statusBadge = document.querySelector(`.recommendation-${recommendationId} .status-badge`);
    if (statusBadge) {
        statusBadge.textContent = 'Aplicada';
        statusBadge.classList.remove('bg-warning');
        statusBadge.classList.add('bg-success');
    }
}

function dismissRecommendation(recommendationId) {
    // En un entorno real, esto sería una llamada AJAX al servidor
    console.log(`Descartar recomendación ${recommendationId}`);
    alert('Recomendación descartada');
    
    // Actualizar la interfaz de usuario
    const statusBadge = document.querySelector(`.recommendation-${recommendationId} .status-badge`);
    if (statusBadge) {
        statusBadge.textContent = 'Descartada';
        statusBadge.classList.remove('bg-warning');
        statusBadge.classList.add('bg-secondary');
    }
}