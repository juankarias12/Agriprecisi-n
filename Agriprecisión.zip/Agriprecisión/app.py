# app.py - Archivo principal de la aplicación Flask
# Juan Carlos Arias gonzalez-2225007


# Flask y extensiones básicas
from flask import Flask, render_template, redirect, url_for, flash, request, session, jsonify, Blueprint

# Autenticación con Flask-Login
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user
)

# SocketIO para actualizaciones en tiempo real
# Added: Import Flask-SocketIO for real-time updates
from flask_socketio import SocketIO, emit

# Manejo de fechas y zonas horarias
from datetime import datetime, timedelta, timezone
# Modelos y base de datos
from models import db, User, Crop, Alert, Recommendation, Field, SoilAnalysis, Priority, PestIncidence
# Configuración de la aplicación
from config import Config
# Funciones de bases de datos
from sqlalchemy import desc, func  # 'func' es útil si haces cálculos en consultas
import random

app = Flask(__name__)
app.config.from_object(Config)

# Configuración de base de datos
db.init_app(app)

# Configuración de login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Added: Initialize SocketIO
socketio = SocketIO(app)

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except ValueError:
        return None

# Admin Blueprint
# Modified: Moved admin_bp definition here to ensure proper scope
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Admin Routes
# Added: Admin panel route to match base.html navigation
@admin_bp.route('/')
@login_required
def admin_panel():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    users = User.query.count()
    crops = Crop.query.count()
    alerts = Alert.query.filter_by(is_read=False).count()
    return render_template('admin/admin_panel.html', users=users, crops=crops, alerts=alerts)

# Added: User management actions to complete admin functionality
@admin_bp.route('/users/register', methods=['POST'])
@login_required
def register_user():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    data = request.form
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    role = data.get('role')
    
    if not all([name, email, password, role]):
        flash('Todos los campos son obligatorios.', 'danger')
        return redirect(url_for('admin.user_management'))
        
    if User.query.filter_by(email=email).first():
        flash('El correo electrónico ya está registrado.', 'danger')
        return redirect(url_for('admin.user_management'))
    
    user = User(
        name=name,
        email=email,
        is_admin=(role == 'admin'),
        created_at=datetime.now(timezone.utc)
    )
    user.set_password(password)
    try:
        db.session.add(user)
        db.session.commit()
        flash('Usuario registrado con éxito.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al registrar usuario: {str(e)}', 'danger')
    return redirect(url_for('admin.user_management'))

@admin_bp.route('/users/<int:id>/edit', methods=['POST'])
@login_required
def edit_user(id):
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    user = User.query.get_or_404(id)
    data = request.form
    user.name = data.get('name')
    user.email = data.get('email')
    user.is_admin = data.get('role') == 'admin'
    try:
        db.session.commit()
        flash('Usuario actualizado con éxito.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al actualizar usuario: {str(e)}', 'danger')
    return redirect(url_for('admin.user_management'))

@admin_bp.route('/users/<int:id>/delete', methods=['POST'])
@login_required
def delete_user(id):
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    user = User.query.get_or_404(id)
    try:
        db.session.delete(user)
        db.session.commit()
        flash('Usuario eliminado con éxito.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar usuario: {str(e)}', 'danger')
    return redirect(url_for('admin.user_management'))

# RF8 Routes (Crop Management and Monitoring)
@admin_bp.route('/crops')
@login_required
def crop_management():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    crops = Crop.query.all()
    fields = Field.query.all()
    return render_template('admin/crop_management.html', crops=crops, fields=fields)

@admin_bp.route('/crops/add', methods=['POST'])
@login_required
def add_crop():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    data = request.form
    planting_date = datetime.strptime(data['planting_date'], '%Y-%m-%d') if data.get('planting_date') else datetime.now(timezone.utc)
    crop = Crop(
        name=data['name'],
        field_id=int(data['field_id']) if data.get('field_id') else None,
        crop_type=data['type'],
        planting_date=planting_date,
        user_id=current_user.id,
        stage=data.get('stage', 'planted'),
        notes=data.get('notes'),
        location=data.get('location'),
        humidity=0.0,
        temperature=0.0
    )
    db.session.add(crop)
    db.session.commit()
    socketio.emit('message', {'type': 'crop_update', 'total_crops': Crop.query.count()}, namespace='/ws/admin')
    flash('Cultivo agregado con éxito.', 'success')
    return redirect(url_for('admin.crop_management'))

@admin_bp.route('/crops/<int:id>/edit', methods=['POST'])
@login_required
def edit_crop(id):
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    crop = Crop.query.get_or_404(id)
    data = request.form
    planting_date = datetime.strptime(data['planting_date'], '%Y-%m-%d') if data.get('planting_date') else crop.planting_date
    crop.name = data['name']
    crop.field_id = int(data['field_id']) if data.get('field_id') else None
    crop.crop_type = data['type']
    crop.planting_date = planting_date
    crop.stage = data.get('stage', crop.stage)
    crop.notes = data.get('notes', crop.notes)
    crop.location = data.get('location', crop.location)
    db.session.commit()
    flash('Cultivo actualizado con éxito.', 'success')
    return redirect(url_for('admin.crop_management'))

@admin_bp.route('/crops/<int:id>/delete', methods=['POST'])
@login_required
def delete_crop(id):
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    crop = Crop.query.get_or_404(id)
    db.session.delete(crop)
    db.session.commit()
    socketio.emit('message', {'type': 'crop_update', 'total_crops': Crop.query.count()}, namespace='/ws/admin')
    flash('Cultivo eliminado con éxito.', 'success')
    return redirect(url_for('admin.crop_management'))

@admin_bp.route('/crops/<int:id>/irrigate', methods=['POST'])
@login_required
def irrigate_crop(id):
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    crop = Crop.query.get_or_404(id)
    alert = Alert(
        title=f"Irrigación iniciada en {crop.name}",
        description=f"Se ha iniciado la irrigación para el cultivo {crop.name} en el campo {crop.field.name if crop.field else 'sin campo'}.",
        priority=Priority.MEDIUM,
        user_id=current_user.id,
        crop_id=crop.id,
        field_id=crop.field_id,
        created_at=datetime.now(timezone.utc)
    )
    db.session.add(alert)
    db.session.commit()
    socketio.emit('message', {
        'type': 'alert',
        'message': f'Irrigación iniciada en {crop.name}',
        'crop_name': crop.name
    }, namespace='/ws/admin')
    socketio.emit('message', {
        'type': 'alert',
        'message': f'Irrigación iniciada',
        'crop_name': crop.name
    }, namespace='/ws/crop-monitoring')
    return jsonify({'status': 'success'}), 200

@admin_bp.route('/crop-monitoring')
@login_required
def crop_monitoring():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    return render_template('admin/crop_monitoring.html')

# Simulate IoT data updates
def simulate_iot_data():
    while True:
        for crop in Crop.query.all():
            crop.humidity = random.uniform(50, 80)
            crop.temperature = random.uniform(20, 30)
            db.session.commit()
            socketio.emit('message', {
                'id': crop.id,
                'humidity': crop.humidity,
                'temperature': crop.temperature
            }, namespace='/ws/crops')
            socketio.emit('message', {
                'type': 'crop_data',
                'humidity': crop.humidity,
                'temperature': crop.temperature,
                'crop_name': crop.name
            }, namespace='/ws/crop-monitoring')
            if crop.humidity < 60:
                alert = Alert(
                    title=f"Baja humedad en {crop.name}",
                    description=f"La humedad del cultivo {crop.name} es {crop.humidity:.1f}%, por debajo del umbral recomendado.",
                    priority=Priority.HIGH,
                    user_id=crop.user_id,
                    crop_id=crop.id,
                    field_id=crop.field_id,
                    created_at=datetime.now(timezone.utc)
                )
                db.session.add(alert)
                db.session.commit()
                socketio.emit('message', {
                    'type': 'alert',
                    'message': f'Baja humedad detectada ({crop.humidity:.1f}%)',
                    'crop_name': crop.name
                }, namespace='/ws/crop-monitoring')
        socketio.sleep(60)

# WebSocket namespaces
@socketio.on('connect', namespace='/ws/crops')
def handle_crops_connect():
    emit('message', {'status': 'Connected to crop updates'}, namespace='/ws/crops')

@socketio.on('connect', namespace='/ws/crop-monitoring')
def handle_monitoring_connect():
    emit('message', {'status': 'Connected to monitoring updates'}, namespace='/ws/crop-monitoring')

@socketio.on('connect', namespace='/ws/admin')
def handle_admin_connect():
    emit('message', {'status': 'Connected to admin updates'}, namespace='/ws/admin')

# Rutas para autenticación
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Credenciales inválidas. Por favor intente de nuevo.', 'danger')
    
    return render_template('auth/login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not all([name, email, password]):
            flash('Todos los campos son obligatorios.', 'danger')
            return redirect(url_for('register'))
            
        if User.query.filter_by(email=email).first():
            flash('El correo electrónico ya está registrado.', 'danger')
            return redirect(url_for('register'))
        
        new_user = User(name=name, email=email)
        new_user.set_password(password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('¡Registro exitoso! Ahora puede iniciar sesión.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al registrar el usuario: {str(e)}', 'danger')
            return redirect(url_for('register'))
    
    return render_template('auth/register.html')

# Rutas principales
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    try:
        crops = Crop.query.filter_by(user_id=current_user.id).all()
        alerts = Alert.query.filter_by(user_id=current_user.id).order_by(Alert.priority.desc(), Alert.created_at.desc()).limit(5).all() if db.inspect(db.engine).has_table('alerts') else []
        fields = Field.query.filter_by(user_id=current_user.id).all()
    except Exception as e:
        flash(f'Error al cargar el dashboard: {str(e)}', 'danger')
        return redirect(url_for('index'))
    
    total_area = sum(field.area for field in fields if field.area)
    total_fields = len(fields)
    expected_yield = sum(crop.expected_yield for crop in crops if crop.expected_yield)
    
    weather = {
        'current': {
            'temperature': 17,
            'condition': 'Mayormente nublado'
        },
        'forecast': [
            {'day': 'Hoy', 'temp_high': 18, 'temp_low': 11, 'condition': 'Parcialmente nublado'},
            {'day': 'Mar.', 'temp_high': 20, 'temp_low': 12, 'condition': 'Parcialmente nublado'},
            {'day': 'Mié.', 'temp_high': 25, 'temp_low': 14, 'condition': 'Parcialmente nublado'}
        ]
    }
    
    return render_template('dashboard.html', 
                          crops=crops,
                          alerts=alerts,
                          fields=fields,
                          total_area=total_area,
                          total_fields=total_fields,
                          expected_yield=expected_yield,
                          weather=weather)

@app.route('/my-crops')
@login_required
def my_crops():
    crops = Crop.query.filter_by(user_id=current_user.id).all()
    fields = Field.query.filter_by(user_id=current_user.id).all()
    return render_template('my_crops.html', crops=crops, fields=fields)

@app.route('/fields', methods=['GET', 'POST'])
@login_required
def fields():
    if request.method == 'POST':
        name = request.form.get('name')
        area = request.form.get('area')
        ph = request.form.get('ph')
        moisture = request.form.get('moisture')
        nitrogen = request.form.get('nitrogen')
        phosphorus = request.form.get('phosphorus')
        potassium = request.form.get('potassium')
        location = request.form.get('location')
        
        if not all([name, area]):
            flash('Nombre y área son obligatorios.', 'danger')
            return redirect(url_for('fields'))
        
        try:
            area = float(area)
            ph = float(ph) if ph else None
            moisture = float(moisture) if moisture else None
            nitrogen = float(nitrogen) if nitrogen else None
            phosphorus = float(phosphorus) if phosphorus else None
            potassium = float(potassium) if potassium else None
        except ValueError:
            flash('Los valores numéricos (área, pH, etc.) deben ser números válidos.', 'danger')
            return redirect(url_for('fields'))
        
        new_field = Field(
            name=name,
            area=area,
            ph=ph,
            moisture=moisture,
            nitrogen=nitrogen,
            phosphorus=phosphorus,
            potassium=potassium,
            location=location,
            user_id=current_user.id
        )
        
        try:
            db.session.add(new_field)
            db.session.commit()
            flash('¡Campo agregado con éxito!', 'success')
            return redirect(url_for('fields'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el campo: {str(e)}', 'danger')
            return redirect(url_for('fields'))
    
    fields = Field.query.filter_by(user_id=current_user.id).all()
    return render_template('fields.html', fields=fields)

@app.route('/soil-analysis/add', methods=['GET', 'POST'])
@login_required
def add_soil_analysis():
    fields = Field.query.filter_by(user_id=current_user.id).all()
    if request.method == 'POST':
        field_id = request.form.get('field_id')
        ph_level = request.form.get('ph_level')
        moisture_level = request.form.get('moisture_level')
        nitrogen_level = request.form.get('nitrogen_level')
        phosphorus_level = request.form.get('phosphorus_level')
        potassium_level = request.form.get('potassium_level')
        notes = request.form.get('notes')

        if not field_id:
            flash('Debes seleccionar un campo.', 'danger')
            return redirect(url_for('add_soil_analysis'))

        try:
            field_id = int(field_id)
            ph_level = float(ph_level) if ph_level else None
            moisture_level = float(moisture_level) if moisture_level else None
            nitrogen_level = float(nitrogen_level) if nitrogen_level else None
            phosphorus_level = float(phosphorus_level) if phosphorus_level else None
            potassium_level = float(potassium_level) if potassium_level else None
        except ValueError:
            flash('Los valores numéricos deben ser números válidos.', 'danger')
            return redirect(url_for('add_soil_analysis'))

        new_analysis = SoilAnalysis(
            field_id=field_id,
            user_id=current_user.id,
            ph_level=ph_level,
            moisture_level=moisture_level,
            nitrogen_level=nitrogen_level,
            phosphorus_level=phosphorus_level,
            potassium_level=potassium_level,
            notes=notes
        )

        try:
            db.session.add(new_analysis)
            db.session.commit()
            flash('¡Análisis de suelo agregado con éxito!', 'success')
            return redirect(url_for('analysis'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el análisis: {str(e)}', 'danger')
            return redirect(url_for('add_soil_analysis'))

    return render_template('soil_analysis_form.html', fields=fields)

@app.route('/analysis/<int:crop_id>')
@login_required
def crop_analysis(crop_id):
    crop = Crop.query.filter_by(id=crop_id, user_id=current_user.id).first_or_404()
    field = crop.field
    soil_analyses = SoilAnalysis.query.filter_by(field_id=field.id).order_by(SoilAnalysis.date.asc()).all()
    pest_incidences = PestIncidence.query.filter_by(crop_id=crop.id).order_by(PestIncidence.date_reported.asc()).all()
    all_crops = Crop.query.filter_by(user_id=current_user.id).all()
    return render_template('crop_analysis.html', crop=crop, soil_analyses=soil_analyses, pest_incidences=pest_incidences, crops=all_crops)

@app.route('/analysis')
@login_required
def analysis():
    crops = Crop.query.filter_by(user_id=current_user.id).all()
    fields = Field.query.filter_by(user_id=current_user.id).all()

    soil_analyses = [sa.to_dict() for sa in SoilAnalysis.query.all()]
    pest_incidences = [pi.to_dict() for pi in PestIncidence.query.all()]
    crop = Crop.query.first().to_dict() if Crop.query.first() else None

    return render_template(
        'analysis.html',
        crops=crops,
        fields=fields,
        soil_analyses=soil_analyses,
        pest_incidences=pest_incidences,
        crop=crop
    )

@app.route('/update-analysis', methods=['POST'])
@login_required
def update_analysis():
    try:
        data = request.get_json()
        crop_id = int(data.get('crop_id'))

        crop = Crop.query.filter_by(id=crop_id, user_id=current_user.id).first()
        if not crop:
            return jsonify({'error': 'Cultivo no encontrado'}), 404

        field = crop.field
        analyses = SoilAnalysis.query.filter(SoilAnalysis.field_id == field.id).order_by(SoilAnalysis.date.desc()).limit(7).all()
        alerts = Alert.query.filter_by(crop_id=crop.id).all()

        dates = [a.date.strftime('%d %b') for a in analyses[::-1]]
        moisture_values = [a.moisture_level or 0 for a in analyses[::-1]]

        avg_moisture = sum(moisture_values) / len(moisture_values) if moisture_values else 0
        max_moisture = max(moisture_values) if moisture_values else 0
        min_moisture = min(moisture_values) if moisture_values else 0
        alert_humidity = 'Se recomienda riego adicional.' if avg_moisture < 30 else 'Niveles óptimos.'

        moisture_chart = {
            'type': 'line',
            'data': {
                'labels': dates,
                'datasets': [{
                    'label': 'Humedad (%)',
                    'data': moisture_values,
                    'borderColor': 'rgba(0, 123, 255, 1)',
                    'backgroundColor': 'rgba(0, 123, 255, 0.1)',
                    'fill': True
                }]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': False,
                'scales': {
                    'y': {'beginAtZero': True, 'max': 100}
                }
            }
        }

        latest = analyses[0] if analyses else None
        nitrogen = latest.nitrogen_level if latest and latest.nitrogen_level is not None else 0
        phosphorus = latest.phosphorus_level if latest and latest.phosphorus_level is not None else 0
        potassium = latest.potassium_level if latest and latest.potassium_level is not None else 0

        nutrients_chart = {
            'type': 'bar',
            'data': {
                'labels': ['Nitrógeno', 'Fósforo', 'Potasio'],
                'datasets': [
                    {
                        'label': 'Niveles actuales (ppm)',
                        'data': [nitrogen, phosphorus, potassium],
                        'backgroundColor': [
                            'rgba(40, 167, 69, 0.7)' if nitrogen >= 20 else 'rgba(255, 193, 7, 0.7)',
                            'rgba(40, 167, 69, 0.7)' if phosphorus >= 15 else 'rgba(255, 193, 7, 0.7)',
                            'rgba(40, 167, 69, 0.7)' if potassium >= 25 else 'rgba(255, 193, 7, 0.7)'
                        ]
                    },
                    {
                        'label': 'Niveles óptimos (ppm)',
                        'data': [45, 25, 80],
                        'type': 'line',
                        'borderColor': 'rgba(220, 53, 69, 0.8)',
                        'pointBackgroundColor': 'rgba(220, 53, 69, 0.8)',
                        'pointRadius': 4
                    }
                ]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': False
            }
        }

        target_yield = (crop.expected_yield or 0) * 1.2 if crop.expected_yield else 1
        yield_chart = {
            'type': 'bar',
            'data': {
                'labels': ['Proyectado', 'Anterior'],
                'datasets': [{
                    'label': 'Rendimiento (t/ha)',
                    'data': [crop.expected_yield or 0, crop.historical_yield or 0],
                    'backgroundColor': ['rgba(40, 167, 69, 0.7)', 'rgba(23, 162, 184, 0.7)']
                }]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': False
            }
        }

        pest_data = []
        pest_summaries = []

        for alert in alerts:
            pest_data.append({
                'label': alert.title,
                'data': [1 if alert.priority == Priority.HIGH else 0.5 if alert.priority == Priority.MEDIUM else 0],
                'borderColor': 'rgba(220, 53, 69, 0.8)',
                'tension': 0.4
            })
            pest_summaries.append({
                'name': alert.title,
                'level': alert.priority.name,
                'trend': 'up' if alert.priority == Priority.HIGH else 'down' if alert.priority == Priority.LOW else 'stable'
            })

        pests_chart = {
            'type': 'line',
            'data': {
                'labels': dates or ['Sin datos'],
                'datasets': pest_data or [{'label': 'Sin plagas', 'data': [0], 'borderColor': 'rgba(220, 53, 69, 0.8)', 'tension': 0.4}]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': False
            }
        }

        return jsonify({
            'moisture_chart': moisture_chart,
            'nutrients_chart': nutrients_chart,
            'yield_chart': yield_chart,
            'pests_chart': pests_chart,
            'summary': {
                'moisture': {
                    'average': avg_moisture,
                    'max': max_moisture,
                    'min': min_moisture,
                    'alert': alert_humidity
                },
                'nutrients': {
                    'nitrogen': {'level': nitrogen, 'status': 'Óptimo' if nitrogen >= 20 else 'Bajo'},
                    'phosphorus': {'level': phosphorus, 'status': 'Óptimo' if phosphorus >= 15 else 'Bajo'},
                    'potassium': {'level': potassium, 'status': 'Óptimo' if potassium >= 25 else 'Bajo'}
                },
                'yield': {
                    'projected': crop.expected_yield or 0,
                    'target': target_yield,
                    'previous': crop.historical_yield or 0,
                    'percentage': ((crop.expected_yield or 0) / target_yield * 100) if target_yield != 0 else 0
                },
                'pests': pest_summaries
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/recommendations')
@login_required
def recommendations():
    if not current_user.crops or len(current_user.crops) == 0:
        try:
            field = Field(
                name="Campo Simulado",
                area=10,
                user_id=current_user.id,
                ph=5.0,
                moisture=20,
                nitrogen=30,
                phosphorus=25,
                potassium=35
            )
            db.session.add(field)
            planting_date = datetime(2025, 1, 1)
            crop = Crop(
                name="Tomate Simulado",
                crop_type="Tomate",
                planting_date=planting_date,
                field_id=field.id,
                user_id=current_user.id
            )
            db.session.add(crop)
            db.session.commit()
            db.session.refresh(current_user)
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear cultivo simulado: {str(e)}', 'danger')
            return render_template('recommendations.html', current_user=current_user)
    
    return render_template('recommendations.html', current_user=current_user)

@app.route('/soil-maps')
@login_required
def soil_maps():
    return render_template('soil_maps.html')

# Función auxiliar para generar alertas automáticas
def generate_alerts(field_id, crop_id, user_id):
    alerts = []
    try:
        if field_id:
            field = Field.query.get(field_id)
            if field:
                latest_analysis = SoilAnalysis.query.filter_by(field_id=field_id).order_by(SoilAnalysis.date.desc()).first()
                
                ph = latest_analysis.ph_level if latest_analysis and latest_analysis.ph_level is not None else field.ph or 0
                moisture = latest_analysis.moisture_level if latest_analysis and latest_analysis.moisture_level is not None else field.moisture or 0
                nitrogen = latest_analysis.nitrogen_level if latest_analysis and latest_analysis.nitrogen_level is not None else field.nitrogen or 0
                phosphorus = latest_analysis.phosphorus_level if latest_analysis and latest_analysis.phosphorus_level is not None else field.phosphorus or 0
                potassium = latest_analysis.potassium_level if latest_analysis and latest_analysis.potassium_level is not None else field.potassium or 0

                if ph and (ph < 5.5 or ph > 7.5):
                    alerts.append(Alert(
                        title="pH Crítico",
                        description=f"El pH del suelo es {ph} (ideal: 5.5-7.5). Ajuste necesario.",
                        priority=Priority.HIGH,
                        crop_id=crop_id,
                        field_id=field_id,
                        user_id=user_id
                    ))
                if moisture < 30:
                    alerts.append(Alert(
                        title="Humedad Baja",
                        description=f"La humedad es {moisture}%. Regar de inmediato.",
                        priority=Priority.HIGH,
                        crop_id=crop_id,
                        field_id=field_id,
                        user_id=user_id
                    ))
                if nitrogen < 20:
                    alerts.append(Alert(
                        title="Nitrógeno Bajo",
                        description=f"Nivel de nitrógeno: {nitrogen} mg/kg. Aumentar fertilización.",
                        priority=Priority.MEDIUM,
                        crop_id=crop_id,
                        field_id=field_id,
                        user_id=user_id
                    ))
                if phosphorus < 15:
                    alerts.append(Alert(
                        title="Fósforo Bajo",
                        description=f"Nivel de fósforo: {phosphorus} mg/kg. Aumentar fertilización.",
                        priority=Priority.MEDIUM,
                        crop_id=crop_id,
                        field_id=field_id,
                        user_id=user_id
                    ))
                if potassium < 25:
                    alerts.append(Alert(
                        title="Potasio Bajo",
                        description=f"Nivel de potasio: {potassium} mg/kg. Aumentar fertilización.",
                        priority=Priority.MEDIUM,
                        crop_id=crop_id,
                        field_id=field_id,
                        user_id=user_id
                    ))

                if alerts:
                    for alert in alerts:
                        db.session.add(alert)
                    db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Error generating alerts: {e}")

@app.route('/crop/add', methods=['GET', 'POST'])
@login_required
def add_crop():
    fields = Field.query.filter_by(user_id=current_user.id).all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        field_id = request.form.get('field_id')
        crop_type = request.form.get('crop_type')
        planting_date = request.form.get('planting_date')
        expected_yield = request.form.get('expected_yield')
        stage = request.form.get('stage')
        notes = request.form.get('notes')
        
        if not all([name, crop_type, planting_date, stage]):
            flash('Nombre, tipo de cultivo, fecha de siembra y etapa son obligatorios.', 'danger')
            return redirect(url_for('add_crop'))
            
        try:
            field_id = int(field_id) if field_id else None
        except ValueError:
            flash('ID de campo inválido.', 'danger')
            return redirect(url_for('add_crop'))
        
        try:
            planting_date = datetime.strptime(planting_date, '%Y-%m-%d')
        except ValueError:
            flash('Fecha de siembra inválida. Use el formato YYYY-MM-DD.', 'danger')
            return redirect(url_for('add_crop'))
            
        try:
            expected_yield = float(expected_yield) if expected_yield else None
        except ValueError:
            flash('Rendimiento esperado inválido. Debe ser un número.', 'danger')
            return redirect(url_for('add_crop'))

        recommendation_text = None
        if field_id:
            field = Field.query.get(field_id)
            if field:
                analyses = SoilAnalysis.query.filter_by(field_id=field.id).order_by(SoilAnalysis.date.desc()).all()

                avg_ph = field.ph or 0
                avg_moisture = field.moisture or 0
                avg_nitrogen = field.nitrogen or 0
                avg_phosphorus = field.phosphorus or 0
                avg_potassium = field.potassium or 0

                if analyses:
                    ph_values = [a.ph_level for a in analyses if a.ph_level is not None]
                    moisture_values = [a.moisture_level for a in analyses if a.moisture_level is not None]
                    nitrogen_values = [a.nitrogen_level for a in analyses if a.nitrogen_level is not None]
                    phosphorus_values = [a.phosphorus_level for a in analyses if a.phosphorus_level is not None]
                    potassium_values = [a.potassium_level for a in analyses if a.potassium_level is not None]

                    avg_ph = sum(ph_values) / len(ph_values) if ph_values else avg_ph
                    avg_moisture = sum(moisture_values) / len(moisture_values) if moisture_values else avg_moisture
                    avg_nitrogen = sum(nitrogen_values) / len(nitrogen_values) if nitrogen_values else avg_nitrogen
                    avg_phosphorus = sum(phosphorus_values) / len(phosphorus_values) if phosphorus_values else avg_phosphorus
                    avg_potassium = sum(potassium_values) / len(potassium_values) if potassium_values else avg_potassium

                if expected_yield:
                    if avg_nitrogen < 20:
                        expected_yield *= 0.9
                    if avg_phosphorus < 15:
                        expected_yield *= 0.9
                    if avg_potassium < 25:
                        expected_yield *= 0.9
                    if avg_moisture < 30:
                        expected_yield *= 0.85

                recommendations = []
                if avg_ph and (avg_ph < 5.5 or avg_ph > 7.5):
                    recommendations.append("Ajuste el pH del suelo (promedio histórico: {:.1f}, ideal: 5.5-7.5).".format(avg_ph))
                if avg_moisture and avg_moisture < 30:
                    recommendations.append("El promedio de humedad es bajo ({:.1f}%). Considere regar más.".format(avg_moisture))
                if avg_nitrogen and avg_nitrogen < 20:
                    recommendations.append("El promedio de nitrógeno es bajo ({:.1f} mg/kg). Aumente fertilización.".format(avg_nitrogen))
                if avg_phosphorus and avg_phosphorus < 15:
                    recommendations.append("El promedio de fósforo es bajo ({:.1f} mg/kg). Aumente fertilización.".format(avg_phosphorus))
                if avg_potassium and avg_potassium < 25:
                    recommendations.append("El promedio de potasio es bajo ({:.1f} mg/kg). Aumente fertilización.".format(avg_potassium))

                if recommendations:
                    recommendation_text = "Recomendaciones para el cultivo '{}': {}".format(name, " ".join(recommendations))
                else:
                    recommendation_text = "Las condiciones del suelo son óptimas para el cultivo '{}' según los datos históricos.".format(name)
        
        new_crop = Crop(
            name=name,
            field_id=field_id,
            crop_type=crop_type,
            planting_date=planting_date,
            expected_yield=expected_yield,
            user_id=current_user.id,
            stage=stage,
            notes=notes
        )
        
        try:
            db.session.add(new_crop)
            db.session.commit()
            
            if field_id:
                generate_alerts(field_id, new_crop.id, current_user.id)
            
            if recommendation_text:
                new_recommendation = Recommendation(
                    content=recommendation_text,
                    crop_id=new_crop.id,
                    user_id=current_user.id
                )
                db.session.add(new_recommendation)
                db.session.commit()
            
            flash('¡Cultivo agregado con éxito!', 'success')
            if recommendation_text:
                flash(recommendation_text, 'info')
            return redirect(url_for('my_crops'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el cultivo: {str(e)}', 'danger')
            return redirect(url_for('add_crop'))
    
    return render_template('crop_form.html', fields=fields)

@app.route('/crop/edit/<int:crop_id>', methods=['GET', 'POST'])
@login_required
def edit_crop(crop_id):
    crop = Crop.query.get_or_404(crop_id)
    if crop.user_id != current_user.id:
        flash('No tienes permiso para editar este cultivo.', 'danger')
        return redirect(url_for('my_crops'))
    
    fields = Field.query.filter_by(user_id=current_user.id).all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        field_id = request.form.get('field_id')
        crop_type = request.form.get('crop_type')
        planting_date = request.form.get('planting_date')
        expected_yield = request.form.get('expected_yield')
        stage = request.form.get('stage')
        notes = request.form.get('notes')
        location = request.form.get('location')
        
        if not all([name, crop_type, planting_date, stage]):
            flash('Nombre, tipo de cultivo, fecha de siembra y etapa son obligatorios.', 'danger')
            return redirect(url_for('edit_crop', crop_id=crop_id))
            
        try:
            field_id = int(field_id) if field_id else None
        except ValueError:
            flash('ID de campo inválido.', 'danger')
            return redirect(url_for('edit_crop', crop_id=crop_id))
        
        try:
            planting_date = datetime.strptime(planting_date, '%Y-%m-%d')
        except ValueError:
            flash('Fecha de siembra inválida. Use el formato YYYY-MM-DD.', 'danger')
            return redirect(url_for('edit_crop', crop_id=crop_id))
            
        try:
            expected_yield = float(expected_yield) if expected_yield else None
        except ValueError:
            flash('Rendimiento esperado inválido. Debe ser un número.', 'danger')
            return redirect(url_for('edit_crop', crop_id=crop_id))
        
        crop.name = name
        crop.field_id = field_id
        crop.crop_type = crop_type
        crop.planting_date = planting_date
        crop.expected_yield = expected_yield
        crop.stage = stage
        crop.notes = notes
        crop.location = location
        
        try:
            db.session.commit()
            flash('¡Cultivo actualizado con éxito!', 'success')
            return redirect(url_for('my_crops'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el cultivo: {str(e)}', 'danger')
            return redirect(url_for('edit_crop', crop_id=crop_id))
    
    return render_template('crop_form.html', crop=crop, fields=fields)

# Modified: Updated admin_dashboard to redirect to admin_panel
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    return redirect(url_for('admin.admin_panel'))

@app.route('/admin/users')
@login_required
def user_management():
    if not current_user.is_admin:
        flash('Acceso denegado. Se requiere permisos de administrador.', 'danger')
        return redirect(url_for('dashboard'))
    
    page = request.args.get('page', 1, type=int)
    users = User.query.paginate(page=page, per_page=10)
    return render_template('admin/user_management.html', users=users)

if __name__ == '__main__':
    # Added: Register blueprint and start SocketIO
    app.register_blueprint(admin_bp)
    socketio.start_background_task(simulate_iot_data)
    with app.app_context():
        db.create_all()
    socketio.run(app, debug=True)