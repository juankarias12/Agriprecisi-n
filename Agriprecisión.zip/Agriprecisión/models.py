#models py

# Juan Carlos Arias-2225007

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timezone
from enum import IntEnum

db = SQLAlchemy()

class Priority(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    
    crops = db.relationship('Crop', backref='user', lazy=True)
    fields = db.relationship('Field', backref='user', lazy=True)
    alerts = db.relationship('Alert', backref='user', lazy=True)
    recommendations = db.relationship('Recommendation', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<User {self.email}>"

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'is_admin': self.is_admin,
            'created_at': self.created_at.isoformat()
        }

class Field(db.Model):
    __tablename__ = 'fields'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    area = db.Column(db.Float, nullable=False)
    ph = db.Column(db.Float)
    moisture = db.Column(db.Float)
    nitrogen = db.Column(db.Float)
    phosphorus = db.Column(db.Float)
    potassium = db.Column(db.Float)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    crops = db.relationship('Crop', backref='field', lazy=True)
    soil_analyses = db.relationship('SoilAnalysis', backref='field', lazy=True)
    pest_incidences = db.relationship('PestIncidence', backref='field', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'area': self.area,
            'ph': self.ph,
            'moisture': self.moisture,
            'nitrogen': self.nitrogen,
            'phosphorus': self.phosphorus,
            'potassium': self.potassium,
            'user_id': self.user_id
        }

class Crop(db.Model):
    __tablename__ = 'crops'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    field_id = db.Column(db.Integer, db.ForeignKey('fields.id'), nullable=True, index=True)
    crop_type = db.Column(db.String(50), nullable=False)
    planting_date = db.Column(db.DateTime, nullable=False)
    expected_yield = db.Column(db.Float, nullable=True)
    historical_yield = db.Column(db.Float, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    stage = db.Column(db.String(50), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    location = db.Column(db.String(200), nullable=True)
    humidity = db.Column(db.Float, default=0.0)  # Added for real-time monitoring
    temperature = db.Column(db.Float, default=0.0)  # Added for real-time monitoring
    recommendations = db.relationship('Recommendation', backref='crop', lazy=True)
    alerts = db.relationship('Alert', backref='crop', lazy=True)
    pest_incidences = db.relationship('PestIncidence', backref='crop', lazy=True)

    def __repr__(self):
        return f"<Crop {self.name} (Field {self.field_id})>"

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'field_id': self.field_id,
            'crop_type': self.crop_type,
            'planting_date': self.planting_date.isoformat() if self.planting_date else None,
            'expected_yield': self.expected_yield,
            'historical_yield': self.historical_yield,
            'user_id': self.user_id,
            'stage': self.stage,
            'notes': self.notes,
            'location': self.location
        }

class Alert(db.Model):
    __tablename__ = 'alerts'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    priority = db.Column(db.Integer, default=Priority.LOW)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    
    crop_id = db.Column(db.Integer, db.ForeignKey('crops.id'), nullable=True, index=True)
    field_id = db.Column(db.Integer, db.ForeignKey('fields.id'), nullable=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)

    def __repr__(self):
        return f"<Alert {self.title} (Priority {self.priority})>"

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'priority': self.priority,
            'is_read': self.is_read,
            'created_at': self.created_at.isoformat(),
            'crop_id': self.crop_id,
            'field_id': self.field_id,
            'user_id': self.user_id
        }

class SoilAnalysis(db.Model):
    __tablename__ = 'soil_analyses'
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    ph_level = db.Column(db.Float, nullable=True)
    nitrogen_level = db.Column(db.Float, nullable=True)
    phosphorus_level = db.Column(db.Float, nullable=True)
    potassium_level = db.Column(db.Float, nullable=True)
    organic_matter = db.Column(db.Float, nullable=True)
    moisture_level = db.Column(db.Float, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    field_id = db.Column(db.Integer, db.ForeignKey('fields.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)

    def __repr__(self):
        return f"<SoilAnalysis (Field {self.field_id}, Date {self.date})>"

    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat(),
            'ph_level': self.ph_level,
            'nitrogen_level': self.nitrogen_level,
            'phosphorus_level': self.phosphorus_level,
            'potassium_level': self.potassium_level,
            'organic_matter': self.organic_matter,
            'moisture_level': self.moisture_level,
            'notes': self.notes,
            'field_id': self.field_id,
            'user_id': self.user_id
        }

class PestIncidence(db.Model):
    __tablename__ = 'pest_incidences'
    id = db.Column(db.Integer, primary_key=True)
    pest_name = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.Integer, nullable=False)
    date_reported = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    notes = db.Column(db.Text, nullable=True)
    crop_id = db.Column(db.Integer, db.ForeignKey('crops.id'), nullable=True, index=True)
    field_id = db.Column(db.Integer, db.ForeignKey('fields.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)

    def __repr__(self):
        return f"<PestIncidence {self.pest_name} (Crop {self.crop_id}, Severity {self.severity})>"

    def to_dict(self):
        return {
            'id': self.id,
            'pest_name': self.pest_name,
            'severity': self.severity,
            'date_reported': self.date_reported.isoformat(),
            'notes': self.notes,
            'crop_id': self.crop_id,
            'field_id': self.field_id,
            'user_id': self.user_id
        }

class Recommendation(db.Model):
    __tablename__ = 'recommendations'
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    crop_id = db.Column(db.Integer, db.ForeignKey('crops.id'), nullable=True, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)

    def __repr__(self):
        return f"<Recommendation (User {self.user_id}, Crop {self.crop_id})>"

    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'created_at': self.created_at.isoformat(),
            'crop_id': self.crop_id,
            'user_id': self.user_id
        }