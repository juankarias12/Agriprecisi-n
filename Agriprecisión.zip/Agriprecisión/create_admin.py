from app import app, db, User

with app.app_context():
    # Check if admin user already exists to avoid duplicates
    if not User.query.filter_by(email="admin@example.com").first():
        user = User(name="Admin", email="admin@example.com", is_admin=True)
        user.set_password("password")
        db.session.add(user)
        db.session.commit()
        print("Admin user created successfully.")
    else:
        print("Admin user already exists.")