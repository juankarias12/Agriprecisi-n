# config.py - Configuración de la aplicación
import os
from datetime import timedelta

class Config:
    # Configuración básica
    basedir = os.path.abspath(os.path.dirname(__file__))
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(24).hex()  # Clave segura por defecto
    
    # Configuración de la base de datos
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(basedir, 'agriprecision.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Configuración de la sesión
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # Configuración de carga de archivos
    UPLOAD_FOLDER = os.path.join(basedir, 'static/uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB máximo

    # Asegurar que el directorio de uploads exista
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)